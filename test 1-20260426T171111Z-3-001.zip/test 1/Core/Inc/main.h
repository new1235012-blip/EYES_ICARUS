/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define sensor3_1_Pin GPIO_PIN_13
#define sensor3_1_GPIO_Port GPIOC
#define sensor3_2_Pin GPIO_PIN_14
#define sensor3_2_GPIO_Port GPIOC
#define sensor3_3_Pin GPIO_PIN_15
#define sensor3_3_GPIO_Port GPIOC
#define sensor1_1_Pin GPIO_PIN_1
#define sensor1_1_GPIO_Port GPIOA
#define sensor1_2_Pin GPIO_PIN_2
#define sensor1_2_GPIO_Port GPIOA
#define sensor1_3_Pin GPIO_PIN_3
#define sensor1_3_GPIO_Port GPIOA
#define mosfet1_1_Pin GPIO_PIN_5
#define mosfet1_1_GPIO_Port GPIOA
#define mosfet1_2_Pin GPIO_PIN_6
#define mosfet1_2_GPIO_Port GPIOA
#define mosfet1_3_Pin GPIO_PIN_7
#define mosfet1_3_GPIO_Port GPIOA
#define button1_Pin GPIO_PIN_12
#define button1_GPIO_Port GPIOB
#define button2_Pin GPIO_PIN_13
#define button2_GPIO_Port GPIOB
#define button3_Pin GPIO_PIN_14
#define button3_GPIO_Port GPIOB
#define sensor2_3_Pin GPIO_PIN_10
#define sensor2_3_GPIO_Port GPIOA
#define sensor2_2_Pin GPIO_PIN_11
#define sensor2_2_GPIO_Port GPIOA
#define sensor2_1_Pin GPIO_PIN_12
#define sensor2_1_GPIO_Port GPIOA
#define mosfet1_3B3_Pin GPIO_PIN_3
#define mosfet1_3B3_GPIO_Port GPIOB
#define mosfet2_1_Pin GPIO_PIN_4
#define mosfet2_1_GPIO_Port GPIOB
#define mosfet2_2_Pin GPIO_PIN_5
#define mosfet2_2_GPIO_Port GPIOB
#define mosfet2_3_Pin GPIO_PIN_6
#define mosfet2_3_GPIO_Port GPIOB
#define mosfet3_1_Pin GPIO_PIN_7
#define mosfet3_1_GPIO_Port GPIOB
#define mosfet3_2_Pin GPIO_PIN_8
#define mosfet3_2_GPIO_Port GPIOB
#define mosfet3_3_Pin GPIO_PIN_9
#define mosfet3_3_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
